Implement and validate the TinyGo → Propeller 2 experiment in this folder on this native M2 Mac. A Propeller 2 is connected by USB serial.

Read AGENTS.md, README.md, docs/SOURCE_AUDIT.md, docs/ACCEPTANCE.md and reports/host-validation.json first. Treat the existing code as a source-audited starting implementation, NOT a proven compiler port. The host tests ran elsewhere; the TinyGo/LLVM integration and hardware did not.

The immediate target is exactly this: TinyGo v0.23.0 + ne75's existing LLVM 14-development P2 backend must produce a genuine P2 object containing the C-callable Go function p2_add(a uint32, b uint32) uint32. Do not modernize LLVM first or implement a full Go runtime. The supplied compiler hook is designed to isolate this proof without runtime.alloc, package initialization, GC or goroutines.

Run the host tests and preflight. Fetch the locked sources and workspace-local Go 1.18.10. Build native arm64 LLVM/P2 with two jobs initially. Run the C backend control, then make probe (addition only). Investigate and fix actual build/API/codegen errors; retain minimal patches and logs. If the direct compiler hook needs adjustment, inspect the pinned TinyGo source, preserve its real SSA-to-LLVM lowering, and keep the no-runtime and C-ABI checks intact.

Once addition emits a valid object, preserve that result. Then run make probe-full, build the P2 libraries and pinned ELF-capable loadp2, and build the separate C baseline and C-calling-Go firmware. The source and artifact hash checks, P2 ELF machine checks and disassembly are part of acceptance, not optional decoration.

Before transmitting, enumerate the actual USB serial devices and verify the connected P2 board and clock. Prior context identifies P2-EC32MB Rev B with a 20 MHz TCXO; /dev/cu.usbserial-P97cvdxp is a historical hint only. Use an unambiguous verified device. The user authorizes RAM-only reset/download to that P2 for these tests; do not touch flash, SD, PSRAM, boot settings, non-console GPIO or other attached devices. Use the provided --allow-ram-reset runner, not a new reset/serial scheme.

Run the C baseline first, then the Go image with edge cases and at least 128 fresh random operand pairs. Require the correct image marker, request nonce and both computed results for every reply. Repeat the Go test across three fresh RAM downloads. If feasible after a successful run, perform the documented Go-source mutation negative control, restore the original source, rebuild and pass again.

Do not substitute handwritten LLVM IR, C implementations of the Go functions, host simulation or canned serial text. A host test or an ELF object is not hardware proof. Do not start multicog Go or goroutines during this task.

Create reports/CODEX_REPORT.md with completed gates, exact tool/source versions, patches, all successful and failed test outcomes, hashes, serial transcript locations and any remaining blocker. Run make evidence and create a compact return archive of reports, patches, relevant logs and resulting .ll/.o/.s/.elf/map/disassembly artifacts; exclude the large LLVM source/build tree and toolchain caches. Continue implementing rather than answering only with a plan. If a gate remains blocked, return the highest verified result and the exact reproducible failing command/error without inflating the result.
