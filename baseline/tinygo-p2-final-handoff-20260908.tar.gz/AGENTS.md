# Task contract: TinyGo v0.23.0 + existing P2LLVM, then M2 USB-serial validation

## Objective and order

1. Produce `.work/out/probe-add/go.o` from the actual `probe/arith.go` `P2Add` function using the pinned TinyGo compiler and P2 backend.
2. Expand to `p2_mix`, link both with C startup/serial code, and execute randomized arithmetic challenges on the physical P2.
3. Record exactly which gates passed; return usable logs, patches, artifacts and a report.

Do not begin LLVM modernization, a full TinyGo runtime, multicog scheduling, goroutines, GC, a new board abstraction, or a language comparison. Those are later projects. Do not stop at a plan: run the commands and fix concrete blockers within scope.

## Preserve truth

- Read README.md, docs/SOURCE_AUDIT.md, docs/ACCEPTANCE.md and reports/host-validation.json before changing code.
- The supplied host tests passed, but the LLVM/TinyGo integration and hardware have NOT been run by the author. Do not call the overlay tested merely because gofmt parsed it.
- Existing generated fixtures in `tests/` are synthetic parser tests, never P2 machine code or evidence.
- Do not generate the arithmetic in C and claim Go, manually write its LLVM IR, retarget ARM/WASM IR, or fake serial output.
- Keep `//export p2_add` and the two-word C ABI. Reject hidden closure parameters, accidental host objects, undefined runtime symbols and empty/optimized-away functions.
- Do not remove assertions/validation merely to make a gate pass. Correct a demonstrably wrong checker only with source evidence, a regression test and an explanation.
- Pin the four source revisions and Go 1.18.10. Record minimal compatibility patches; do not silently upgrade the compiler stack or its Go LLVM binding.
- The two-function hardware image has no C fallback implementation of p2_add/p2_mix. Maintain that separation.
- Keep all build and serial failure logs. Label host, compiler, link and physical-device results separately.

## Safety and workspace boundaries

- Work inside this folder and its `.work` directory. Do not reset, clean, rebase or overwrite existing user repositories or global toolchains.
- Do not use sudo, disable signing/security, change system-wide serial drivers, or modify shell startup files.
- Prefer existing developer tools. Missing Xcode tools or permissions that require user UI should be reported as a precise blocker, not guessed around.
- The Mac is Apple Silicon M2. Compile natively for arm64, not Rosetta. Start with P2_JOBS=2.
- The previously identified board is P2-EC32MB Rev B, external 20 MHz TCXO. The old serial name is only a hint. Enumerate currently present devices and verify the board/clock profile.
- With exactly one positively identified connected P2 console, the user authorizes RAM-only load/reset for this task. Use the provided explicit --allow-ram-reset action. With ambiguous devices, do not guess or transmit to each one.
- Do not write SPI flash, EEPROM, SD, PSRAM, boot configuration or fuses. Do not change non-console GPIO or run actuators. No flashloader binaries, no -9 filesystem server, no @address multi-file loader commands.
- Let the pinned ne75/loadp2 own serial/DTR. Do not open a second serial connection after uploading or toggle DTR manually.
- Do not kill processes holding the serial port. Report the conflict.

## Implementation strategy

- Source checkout, LLVM shared libraries, library paths, compiler hook, C harness, artifact checker and serial protocol are already implemented as a starting point.
- `make probe` is ADD ONLY. `make probe-full` is the later two-function gate. Preserve an add-only success even if the expanded test fails.
- Build an actual P2 backend C control before the Go probe. Confirm `llvm-config --version`, `llc --version` and native architecture of the host binaries.
- The compiler test hook deliberately bypasses runtime/package initialization. It calls TinyGo's real internal function builder and rejects runtime-dependent SSA. This is not a complete TinyGo platform port.
- Use a single P2 LLVM build for go-llvm bindings and object emission; do not accidentally link Homebrew's stock libLLVM or libclang.
- API breakage between the early LLVM 14 fork and final-14-era bindings is plausible. Patch only what compiler diagnostics demonstrate. Preserve diffs and add checks.
- Source edits in `.work/src` are allowed and expected for necessary compatibility fixes. Export them with `make evidence`. The overlay in `overlays/` should remain the source of truth; do not overwrite a differing checkout copy without preserving/merging edits.

## Completion

Follow docs/ACCEPTANCE.md. A primary object-only success is valuable and must be reported accurately even if hardware bring-up remains blocked. A full proof requires live computed results on the P2, not just a READY/PASS banner. Do not claim future background work or leave only a status update. Finish with completed gates, exact remaining blocker(s), file paths and the return report/archive.
